package com.milos.progenios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgeniosApplicationTests {

	@Test
	void contextLoads() {
	}

}
