package com.milos.progenios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgeniosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgeniosApplication.class, args);
	}

}
